package com.example.BookstoreAPI.controller;

public @interface WebMvcTest {

    Class<BookController> value();

}
