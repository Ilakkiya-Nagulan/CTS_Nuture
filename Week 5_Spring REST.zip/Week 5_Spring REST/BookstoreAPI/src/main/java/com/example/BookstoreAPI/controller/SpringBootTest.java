package com.example.BookstoreAPI.controller;

public @interface SpringBootTest {

}
