package com.example.BookstoreAPI.assembler;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.RepresentationModelAssemblerSupport;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import com.example.BookstoreAPI.controller.BookController;
import com.example.BookstoreAPI.model.Book;

@Component
public class BookResourceAssembler extends RepresentationModelAssemblerSupport<Book, EntityModel<Book>> {

    @SuppressWarnings("unchecked")
    public BookResourceAssembler() {
        super(BookController.class, (Class<EntityModel<Book>>)(Class<?>)EntityModel.class);
    }

    @Override
    @NonNull
    public EntityModel<Book> toModel(@NonNull Book book) {
        return EntityModel.of(book,
                linkTo(methodOn(BookController.class).getBookById(book.getId())).withSelfRel(),
                linkTo(methodOn(BookController.class).getAllBooks()).withRel("books"));
    }
}