package com.example.BookstoreAPI.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import io.micrometer.core.instrument.MeterRegistry;

@Configuration
public class CustomMetricsConfig {

    private final MeterRegistry meterRegistry;

    public CustomMetricsConfig(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @Scheduled(fixedRate = 5000)
    public void customMetrics() {
        meterRegistry.counter("custom.metric.counter").increment();
    }
}