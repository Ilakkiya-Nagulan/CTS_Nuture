package com.example.BookstoreAPI.service;

import java.util.List;

import com.example.BookstoreAPI.model.Book;

public interface BookService {
    List<Book> getAllBooks();
    Book getBookById(Long id);
    Book createBook(Book book);
}