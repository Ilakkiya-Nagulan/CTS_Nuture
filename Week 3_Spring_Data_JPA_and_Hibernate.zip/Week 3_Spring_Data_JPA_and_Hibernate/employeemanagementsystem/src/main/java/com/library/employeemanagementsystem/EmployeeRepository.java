package com.library.employeemanagementsystem;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Use method names for query generation
    Page<Employee> findByDepartmentId(Long departmentId, Pageable pageable);

    Page<Employee> findByName(String name, Pageable pageable);

    Employee findByEmail(String email);

    // Custom queries using @Query annotation
    @Query("SELECT e FROM Employee e WHERE e.department.id = :departmentId")
    Page<Employee> findEmployeesByDepartmentId(@Param("departmentId") Long departmentId, Pageable pageable);

    @Query("SELECT e FROM Employee e WHERE e.name = :name")
    Page<Employee> findEmployeesByName(@Param("name") String name, Pageable pageable);

    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    Employee findEmployeeByEmail(@Param("email") String email);
}
