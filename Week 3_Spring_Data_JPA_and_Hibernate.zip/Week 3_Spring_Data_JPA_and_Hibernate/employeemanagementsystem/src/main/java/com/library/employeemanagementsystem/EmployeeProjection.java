package com.library.employeemanagementsystem;

public interface EmployeeProjection {
    Long getId();
    String getName();
    String getEmail();
}
