package com.library.employeemanagementsystem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public Page<Employee> getAllEmployees(Pageable pageable) {
        return employeeService.getAllEmployees(pageable);
    }

    @GetMapping("/department/{departmentId}")
    public Page<Employee> getEmployeesByDepartmentId(@PathVariable Long departmentId, Pageable pageable) {
        return employeeService.getEmployeesByDepartmentId(departmentId, pageable);
    }

    @GetMapping("/name/{name}")
    public Page<Employee> getEmployeesByName(@PathVariable String name, Pageable pageable) {
        return employeeService.getEmployeesByName(name, pageable);
    }
}
