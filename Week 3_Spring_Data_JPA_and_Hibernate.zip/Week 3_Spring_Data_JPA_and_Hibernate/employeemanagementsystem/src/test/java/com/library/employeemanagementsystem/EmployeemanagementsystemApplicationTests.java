package com.library.employeemanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeemanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
