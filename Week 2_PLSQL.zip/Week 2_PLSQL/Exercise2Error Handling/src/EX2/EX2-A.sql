/*
Exercise 2: Error Handling

Scenario 1: Handle exceptions during fund transfers between accounts.
Question: Write a stored procedure SafeTransferFunds that transfers funds between two accounts. Ensure that if any error occurs (e.g., insufficient funds), an appropriate error message is logged and the transaction is rolled back.
*/

CREATE OR REPLACE PROCEDURE SafeTransferFunds (
    p_from_account_id NUMBER,
    p_to_account_id NUMBER,
    p_amount NUMBER
)
IS
  v_from_account_balance NUMBER;
  v_to_account_balance NUMBER;
BEGIN
  -- Check for sufficient funds
  SELECT balance INTO v_from_account_balance
  FROM accounts
  WHERE account_id = p_from_account_id;

  IF v_from_account_balance < p_amount THEN
    RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds');
  END IF;

  -- Begin transaction
  BEGIN
    UPDATE accounts
    SET balance = balance - p_amount
    WHERE account_id = p_from_account_id;

    UPDATE accounts
    SET balance = balance + p_amount
    WHERE account_id = p_to_account_id;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      -- Log error here (e.g., using DBMS_LOG or custom logging mechanism)
      RAISE; -- Re-raise the exception
  END;
END;
