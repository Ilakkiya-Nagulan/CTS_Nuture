/*
Scenario 2: Manage errors when updating employee salaries.
Question: Write a stored procedure UpdateSalary that increases the salary of an employee by a given percentage. If the employee ID does not exist, handle the exception and log an error message.
*/

CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_employee_id NUMBER,
    p_percentage NUMBER
)
IS
BEGIN
  UPDATE employees
  SET salary = salary * (1 + p_percentage / 100)
  WHERE employee_id = p_employee_id;

  IF SQL%NOTFOUND THEN
    RAISE_APPLICATION_ERROR(-20002, 'Employee not found');
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error here (e.g., using DBMS_LOG or custom logging mechanism)
    RAISE; -- Re-raise the exception
END;
