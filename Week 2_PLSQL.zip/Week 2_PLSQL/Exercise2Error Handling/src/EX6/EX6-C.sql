/*
Scenario 3: Update the interest rate for all loans based on a new policy.
Question: Write a PL/SQL block using an explicit cursor UpdateLoanInterestRates that fetches all loans and updates their interest rates based on the new policy.
*/

CREATE OR REPLACE PROCEDURE UpdateLoanInterestRates (p_new_interest_rate NUMBER)
IS
  CURSOR loan_cursor IS
    SELECT loan_id
    FROM loans;

  v_loan_id NUMBER;
BEGIN
  OPEN loan_cursor;
  LOOP
    FETCH loan_cursor INTO v_loan_id;
    EXIT WHEN loan_cursor%NOTFOUND;

    UPDATE loans
    SET interest_rate = p_new_interest_rate
    WHERE loan_id = v_loan_id;
  END LOOP;
  CLOSE loan_cursor;
END;
