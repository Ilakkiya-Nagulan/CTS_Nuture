/*
Exercise 6: Cursors

Scenario 1: Generate monthly statements for all customers.
Question: Write a PL/SQL block using an explicit cursor GenerateMonthlyStatements that retrieves all transactions for the current month and prints a statement for each customer.

*/

CREATE OR REPLACE PROCEDURE GenerateMonthlyStatements
IS
  CURSOR trans_cursor IS
    SELECT c.customer_id, c.name, t.transaction_date, t.amount, t.transaction_type
    FROM customers c
    JOIN accounts a ON c.customer_id = a.customer_id
    JOIN transactions t ON a.account_id = t.account_id
    WHERE t.transaction_date BETWEEN TRUNC(SYSDATE, 'MM') AND LAST_DAY(TRUNC(SYSDATE, 'MM'));

  v_customer_id NUMBER;
  v_customer_name VARCHAR2(100);
  v_transaction_date DATE;
  v_amount NUMBER;
  v_transaction_type VARCHAR2(10);
BEGIN
  OPEN trans_cursor;
  LOOP
    FETCH trans_cursor INTO v_customer_id, v_customer_name, v_transaction_date, v_amount, v_transaction_type;
    EXIT WHEN trans_cursor%NOTFOUND;

    -- Logic to generate statement for each customer based on transaction data
    -- This would typically involve creating a report or sending an email

  END LOOP;
  CLOSE trans_cursor;
END;
