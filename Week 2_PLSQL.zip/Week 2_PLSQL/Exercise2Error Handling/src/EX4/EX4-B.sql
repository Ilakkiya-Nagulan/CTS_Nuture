/*
Scenario 2: The bank needs to compute the monthly installment for a loan.
Question: Write a function CalculateMonthlyInstallment that takes the loan amount, interest rate, and loan duration in years as input and returns the monthly installment amount.

*/

CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment (
  p_loan_amount NUMBER,
  p_interest_rate NUMBER,
  p_loan_duration NUMBER
)
RETURN NUMBER
IS
  v_monthly_interest_rate NUMBER;
  v_num_payments NUMBER;
  v_installment NUMBER;
BEGIN
  v_monthly_interest_rate := p_interest_rate / 1200;
  v_num_payments := p_loan_duration * 12;
  v_installment := (p_loan_amount * v_monthly_interest_rate) / (1 - POWER(1 + v_monthly_interest_rate, -v_num_payments));
  RETURN v_installment;
END;
/
