import java.util.Arrays;

class Product {
    int productId;
    String productName;
    String category;

    public Product(int productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                ", category='" + category + '\'' +
                '}';
    }
}

public class ECommercePlatformSearchFunction {

    public static Product linearSearch(Product[] products, int productId) {
        for (Product product : products) {
            if (product.productId == productId) {
                return product;
            }
        }
        return null; // Product not found
    }

    public static Product binarySearch(Product[] products, int productId) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (products[mid].productId == productId) {
                return products[mid];
            }

            if (products[mid].productId < productId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null; // Product not found
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Smartphone", "Electronics"),
            new Product(3, "Tablet", "Electronics"),
            new Product(4, "Headphones", "Accessories"),
            new Product(5, "Charger", "Accessories"),
            new Product(6, "Camera", "Electronics"),
            new Product(7, "Monitor", "Electronics"),
            new Product(8, "Keyboard", "Accessories"),
            new Product(9, "Mouse", "Accessories"),
            new Product(10, "Printer", "Electronics")
        };

        // Linear Search
        int[] searchIds = {3, 7, 10, 1, 5, 8, 11}; // 7 search queries
        System.out.println("Linear Search Results:");
        for (int id : searchIds) {
            Product result = linearSearch(products, id);
            System.out.println("Searching for productId " + id + ": " + result);
        }

        // Binary Search (requires sorted array)
        Arrays.sort(products, (a, b) -> Integer.compare(a.productId, b.productId));
        System.out.println("\nBinary Search Results:");
        for (int id : searchIds) {
            Product result = binarySearch(products, id);
            System.out.println("Searching for productId " + id + ": " + result);
        }
    }
}