public class AdapterPatternExample {

    public interface PaymentProcessor {
        void processPayment(double amount);
    }

    public static class PayPalPayment {
        public void payWithPayPal(double amount) {
            System.out.println("Processing payment with PayPal: $" + amount);
        }
    }

    public static class StripePayment {
        public void chargeWithStripe(double amount) {
            System.out.println("Processing payment with Stripe: $" + amount);
        }
    }

    
    public static class PayPalAdapter implements PaymentProcessor {
        private PayPalPayment payPalPayment;

        public PayPalAdapter(PayPalPayment payPalPayment) {
            this.payPalPayment = payPalPayment;
        }

        @Override
        public void processPayment(double amount) {
            payPalPayment.payWithPayPal(amount);
        }
    }

    
    public static class StripeAdapter implements PaymentProcessor {
        private StripePayment stripePayment;

        public StripeAdapter(StripePayment stripePayment) {
            this.stripePayment = stripePayment;
        }

        @Override
        public void processPayment(double amount) {
            stripePayment.chargeWithStripe(amount);
        }
    }

    
    public static void main(String[] args) {
        
        PayPalPayment payPalPayment = new PayPalPayment();
        StripePayment stripePayment = new StripePayment();

        
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalPayment);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripePayment);

        
        payPalAdapter.processPayment(100.00);
        stripeAdapter.processPayment(200.00);
    }
}
